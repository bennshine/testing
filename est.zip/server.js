var express = require('express');
var app = express();
var bodyParser = require('body-parser');
const fetch = require("node-fetch");
const basicAuth = require('express-basic-auth')

app.use(bodyParser.json())
app.use(express.static('resources'));
app.use('/files', express.static('files'))


app.use(
  express.urlencoded({
    extended: true,
  })
);
app.use(express.json());

// const session = require('express-session')
// const passwordProtected = require('express-password-protect')
 
// const config = {
// 	username: "admin",
// 	password: "admin",
// 	maxAge: 60000 // 1 minute
// }
 
// app.use(passwordProtected(config))
 


// app.use(basicAuth({
// 	users: { 'admin': 'supersecret' },
// 	challenge: true,
// 	realm: 'foo',
//   }))
//   app.get('/dashboard', (req, res) => {
// 	res.sendFile(path + "dashboard.html");
// });
// app.get('/dashboard', (req, res) => {
// 	res.sendFile(path + "dashboard.html");
// });
// app.get('/dashboard', (req,res) => {
// 	res.sendFile(path + "dashboard.html");
// });

// const basicAuth = require('express-basic-auth');


// app.use(basicAuth({
//     users: { admin: 'admin' },
//     challenge: true // <--- needed to actually show the login dialog!
// }));

// app.use('/admin', basicAuth({
//     users: { admin: 'supersecret123' },
//     challenge: true // <--- needed to actually show the login dialog!
// }));
// app.get('/dashboard', basicAuth({
//     users: { admin: 'supersecret123' },
//     challenge: true // <--- needed to actually show the login dialog!
// }));


const LIVE_API = "http://localhost:8000/";

// for create
app.post("/api/HCDataVis", (req, res) => {
	const {
		ReportType,
		WorkSpace,
		DashboardReport,
		Description,
		ProcessesApplications,
		Access,
		DataFlow,

	} = req.body;

	fetch(LIVE_API + "api/HCDataVis", {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			ReportType,
			WorkSpace,
			DashboardReport,
			Description,
			ProcessesApplications,
			Access,
			DataFlow,
		}),
	})
		.then(() => {
			// res.redirect('back');
			req.flash({
				type: 'info',
				message: 'if cats rules the world',
				redirect: false
			  })

		})
		.catch((e) => {
			res.send(e);
		});
});
// for update
app.post("/api/HCDataVis/update", (req, res) => {
	const {
    id,
	ReportType,
	WorkSpace,
	DashboardReport,
	Description,
	ProcessesApplications,
	Access,
	DataFlow,
	} = req.body;

  const data = {
    id,
	ReportType,
	WorkSpace,
	DashboardReport,
	Description,
	ProcessesApplications,
	Access,
	DataFlow,
  };

  Object.keys(data).forEach((key) => !data[key] && delete data[key]);

	fetch(LIVE_API + "api/HCDataVis", {
		method: "PUT",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(data),
	})
		.then(() => {
			res.redirect('back');

			// res.send("update. success.");
		})
		.catch((e) => {
			res.send(e);
		});
});

// for delete
app.post("/api/HCDataVis/delete", (req, res) => {
	const {
    id
	} = req.body;

  const data = {
    id
  };

  Object.keys(data).forEach((key) => !data[key] && delete data[key]);
	fetch(LIVE_API + `api/HCDataVis/${id}`
	, {
		method: "DELETE",
		headers: { "Content-Type": "application/json" },
	})
		.then(() => {
			res.redirect('back');

			// res.send("delete. success.");
		})
		.catch((e) => {
			res.send(e);
		});
});


global.__basedir = __dirname;
 
require('./app/routes/data.route.js')(app);


// Create a Server
var server = app.listen(8088, function () {
 
  var host = server.address().address
  var port = server.address().port
 
  console.log("App listening at http://%s:%s", host, port) 
})

