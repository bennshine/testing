const fetch = require("node-fetch");
const url = "http://172.30.2.182:90/api/HCPwrPrices";
const url3 = "http://172.30.2.182:90/api/HCEirGrid";
const url4 = "http://172.30.2.182:90/api/HCSemoReports";
const url5 = "http://172.30.2.182:90/api/HCWebScrapper";
const url6 = "http://172.30.2.182:90/api/HCPPBMetered";
const url7 = "http://172.30.2.182:90/api/HCEnAppSys";
const url8 = "http://172.30.2.182:90/api/HCSemoPX";
const url2 = "http://172.30.2.182:90/api/HCvolPrices/1/7";
const url9 = "http://172.30.2.182:90/api/HCvolPrices/2/7";
const url10 = "http://172.30.2.182:90/api/HCvolPrices/3/6";
const url11 = "http://172.30.2.182:90/api/HCvolPrices";
const url12 = "http://172.30.2.182:90/api/HCDataVis/Qlik";
const url13 = "http://172.30.2.182:90/api/HCDataVis/PowerBi";
const url14 = "http://172.30.2.182:90/api/HCDataVis/SSRS";
const url15 = "http://172.30.2.182:90/api/HCDataVis";
const url16 = "http://172.30.2.182:90/api/HCDataVis/Qlik";




exports.getAll = (req, res) => {
    const getData = async url => {
        try {
            const response = await fetch(url);
            const gbprices = await response.json();
            // console.log("--->Get All GBPrices now sorted: \n" + JSON.stringify(gbprices, null, 4));
            res.send(gbprices);

        } catch (error) {
            console.log(error);
        }
    };
    const gettingData = getData(url);
}
exports.getAll2 = (req, res) => {
    const getData = async url => {
        try {
            const response = await fetch(url2);
            const volprices = await response.json();
            // console.log("--->Get All GBPrices now sorted: \n" + JSON.stringify(volprices, null, 4));
            res.send(volprices);

        } catch (error) {
            console.log(error);
        }
    };
    const gettingData = getData(url2);
}
exports.getAll3 = (req, res) => {
    const getData = async url => {
        try {
            const response = await fetch(url3);
            const eirgridprices = await response.json();
            // console.log("--->Get All GBPrices now sorted: \n" + JSON.stringify(eirgridprices, null, 4));
            res.send(eirgridprices);

        } catch (error) {
            console.log(error);
        }
    };
    const gettingData = getData(url3);
}
exports.getAll4 = (req, res) => {
    const getData = async url => {
        try {
            const response = await fetch(url4);
            const semoreportsprices = await response.json();
            // console.log("--->Get All GBPrices now sorted: \n" + JSON.stringify(semoreportsprices, null, 4));
            res.send(semoreportsprices);

        } catch (error) {
            console.log(error);
        }
    };
    const gettingData = getData(url4);
}
exports.getAll5 = (req, res) => {
    const getData = async url => {
        try {
            const response = await fetch(url5);
            const webscrapperprices = await response.json();
            // console.log("--->Get All GBPrices now sorted: \n" + JSON.stringify(webscrapperprices, null, 4));
            res.send(webscrapperprices);

        } catch (error) {
            console.log(error);
        }
    };
    const gettingData = getData(url5);
}
exports.getAll6 = (req, res) => {
    const getData = async url => {
        try {
            const response = await fetch(url6);
            const ppbmeteredprices = await response.json();
            // console.log("--->Get All GBPrices now sorted: \n" + JSON.stringify(ppbmeteredprices, null, 4));
            res.send(ppbmeteredprices);

        } catch (error) {
            console.log(error);
        }
    };
    const gettingData = getData(url6);
}
exports.getAll7 = (req, res) => {
    const getData = async url => {
        try {
            const response = await fetch(url7);
            const enappsysprices = await response.json();
            // console.log("--->Get All GBPrices now sorted: \n" + JSON.stringify(enappsysprices, null, 4));
            res.send(enappsysprices);

        } catch (error) {
            console.log(error);
        }
    };
    const gettingData = getData(url7);
}
exports.getAll8 = (req, res) => {
    const getData = async url => {
        try {
            const response = await fetch(url8);
            const semopxprices = await response.json();
            // console.log("--->Get All GBPrices now sorted: \n" + JSON.stringify(semopxprices, null, 4));
            res.send(semopxprices);

        } catch (error) {
            console.log(error);
        }
    };
    const gettingData = getData(url8);
}

exports.getAll9 = (req, res) => {
    const getData = async url => {
        try {
            const response = await fetch(url9);
            const volprices1 = await response.json();
            // console.log("--->Get All GBPrices now sorted: \n" + JSON.stringify(volprices1, null, 4));
            res.send(volprices1);

        } catch (error) {
            console.log(error);
        }
    };
    const gettingData = getData(url9);
}
exports.getAll10 = (req, res) => {
    const getData = async url => {
        try {
            const response = await fetch(url10);
            const volprices2 = await response.json();
            // console.log("--->Get All GBPrices now sorted: \n" + JSON.stringify(volprices2, null, 4));
            res.send(volprices2);

        } catch (error) {
            console.log(error);
        }
    };
    const gettingData = getData(url10);
}
exports.getAll11 = (req, res) => {
    const getData = async url => {
        try {
            const response = await fetch(url11);
            const volprices0 = await response.json();
            // console.log("--->Get All GBPrices now sorted: \n" + JSON.stringify(volprices0, null, 4));
            res.send(volprices0);

        } catch (error) {
            console.log(error);
        }
    };
    const gettingData = getData(url11);
}
exports.getAll12 = (req, res) => {
    const getData = async url => {
        try {
            const response = await fetch(url12);
            const datavisqlik = await response.json();
            // console.log("--->Get All GBPrices now sorted: \n" + JSON.stringify(datavisqlik, null, 4));
            res.send(datavisqlik);

        } catch (error) {
            console.log(error);
        }
    };
    const gettingData = getData(url12);
}
exports.getAll13 = (req, res) => {
    const getData = async url => {
        try {
            const response = await fetch(url13);
            const datavispb = await response.json();
            // console.log("--->Get All GBPrices now sorted: \n" + JSON.stringify(datavis, null, 4));
            res.send(datavispb);

        } catch (error) {
            console.log(error);
        }
    };
    const gettingData = getData(url13);
}
exports.getAll14 = (req, res) => {
    const getData = async url => {
        try {
            const response = await fetch(url14);
            const datavissrs = await response.json();
            // console.log("--->Get All GBPrices now sorted: \n" + JSON.stringify(datavis, null, 4));
            res.send(datavissrs);

        } catch (error) {
            console.log(error);
        }
    };
    const gettingData = getData(url14);
}
exports.getAll15 = (req, res) => {
    const getData = async url => {
        try {
            const response = await fetch(url15);
            const datavis = await response.json();
            // console.log("--->Get All GBPrices now sorted: \n" + JSON.stringify(datavis, null, 4));
            res.send(datavis);

        } catch (error) {
            console.log(error);
        }
    };
    const gettingData = getData(url15);
}
exports.getAll16 = (req, res) => {
    const getData = async url => {
        try {
            const response = await fetch(url16);
            const datavisa = await response.json();
            // console.log("--->Get All GBPrices now sorted: \n" + JSON.stringify(datavis, null, 4));
            res.send(datavisa);

        } catch (error) {
            console.log(error);
        }
    };
    const gettingData = getData(url16);
}