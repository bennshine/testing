module.exports = function(app) {
 
	var express = require("express");
	var router = express.Router();
	// const fetch = require("node-fetch");


    const gbprices = require('../controllers/api.js');
	const volprices = require('../controllers/api.js');
	const eirgridprices = require('../controllers/api.js');
	const semoreportsprices = require('../controllers/api.js');
	const webscrapperprices = require('../controllers/api.js');
	const ppbmeteredprices = require('../controllers/api.js');
	const enappsysprices = require('../controllers/api.js');
	const semopxprices = require('../controllers/api.js');
	const volprices1 = require('../controllers/api.js');
	const volprices2 = require('../controllers/api.js');
	const volprices0 = require('../controllers/api.js');
	const datavis	= require('../controllers/api.js');



	var path = __basedir + '/views/';
	
	router.use(function (req,res,next) {
		console.log("/" + req.method);
		next();
	});
	
	app.get('/', (req,res) => {
		res.sendFile(path + "index.html");
	});


	// app.post('/postcontent', async (req, res) => {
	// 	console.log("Post end point called");
	// 	const url = `http://localhost:8000/api/HCDataVis`;
	// 	const options = {
	// 		body:    JSON.stringify(body),
	// 		headers: { 'Content-Type': 'application/json' },
	// 	};
	// 	const response = await fetch(url, options)
	// 	.then(res => res.json())
	// 	.catch(e => {
	// 		console.error({
	// 			"message":"oh noes",
	// 			error: e,
	// 		});

	// 	});
	// 	console.log("RESPONSE:", response);
	// 	// res.send(response.url);
	// 	res.json(response);
	// })

    // Retrieve all benn
    app.get('/api/gbprices', gbprices.getAll);
	app.get('/api/volprices/1/7', volprices.getAll2);
	app.get('/api/eirgridprices', eirgridprices.getAll3);
	app.get('/api/semoreportsprices', semoreportsprices.getAll4);
	app.get('/api/webscrapperprices', webscrapperprices.getAll5);
	app.get('/api/ppbmeteredprices', ppbmeteredprices.getAll6);
	app.get('/api/enappsysprices', enappsysprices.getAll7);
	app.get('/api/semopxprices', semopxprices.getAll8);
	app.get('/api/volprices/2/7', volprices1.getAll9);
	app.get('/api/volprices/3/6', volprices2.getAll10);
	app.get('/api/volprices', volprices0.getAll11);
	app.get('/api/HCDataVis', datavis.getAll12);


	app.use("/",router);
 
	app.use("*", (req,res) => {
		res.sendFile(path + "404.html");
	});
}