var express = require('express');
var app = express();
var bodyParser = require('body-parser');
const fetch = require("node-fetch");

app.use(bodyParser.json())
app.use(express.static('resources'));

app.use(
  express.urlencoded({
    extended: true,
  })
);
app.use(express.json());

const LIVE_API = "http://localhost:8000/";

// for create
app.post("/api/HCDataVis", (req, res) => {
	const {
		ReportType,
		WorkSpace,
		DashboardReport,
		Description,
		ProcessesApplications,
		Access,
		DataFlow,

	} = req.body;

	fetch(LIVE_API + "api/HCDataVis", {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			ReportType,
			WorkSpace,
			DashboardReport,
			Description,
			ProcessesApplications,
			Access,
			DataFlow,
		}),
	})
		.then(() => {
			res.redirect('back');

		})
		.catch((e) => {
			res.send(e);
		});
});
// for update
app.post("/api/HCDataVis/update", (req, res) => {
	const {
    id,
	WorkSpace,
	DashboardReport,
	Description,
	ProcessesApplications,
	Access,
	DataFlow,
	} = req.body;

  const data = {
    id,
	WorkSpace,
	DashboardReport,
	Description,
	ProcessesApplications,
	Access,
	DataFlow,
  };

  Object.keys(data).forEach((key) => !data[key] && delete data[key]);

	fetch(LIVE_API + "api/HCDataVis", {
		method: "PUT",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(data),
	})
		.then(() => {
			res.send("update. success.");
		})
		.catch((e) => {
			res.send(e);
		});
});

// for delete


global.__basedir = __dirname;
 
require('./app/routes/data.route.js')(app);


// Create a Server
var server = app.listen(8088, function () {
 
  var host = server.address().address
  var port = server.address().port
 
  console.log("App listening at http://%s:%s", host, port) 
})

