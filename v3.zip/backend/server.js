const express = require("express");
const fetch = require("node-fetch");
const app = express();

app.use(
	express.urlencoded({
		extended: true,
	})
);
app.use(express.json());

const LIVE_API = "http://localhost:8000/";

// for create
app.post("/api/HCDataVis", (req, res) => {
	const {
		ReportingTool,
		ReportName,
		DataSource,
		Description,
		Other,
	} = req.body;

	fetch(LIVE_API + "api/HCDataVis", {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			ReportingTool,
			ReportName,
			DataSource,
			Description,
			Other,
		}),
	})
		.then(() => {
			res.send("done. success.");
		})
		.catch((e) => {
			res.send(e);
		});
});

// for update
app.post("/api/HCDataVis/:id", (req, res) => {
	const {
		ReportingTool,
		ReportName,
		DataSource,
		Description,
		Other,
	} = req.body;

	// id for document being updated
	const id = req.params.id;

	fetch(LIVE_API + "api/HCDataVis/" + id, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			ReportingTool,
			ReportName,
			DataSource,
			Description,
			Other,
		}),
	})
		.then(() => {
			res.send("done. success.");
		})
		.catch((e) => {
			res.send(e);
		});
});

app.listen(3000, () => {
	console.log("server is running on: http://localhost:3000");
});
